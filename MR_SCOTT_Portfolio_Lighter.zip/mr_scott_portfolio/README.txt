MR. SCOTT PORTFOLIO
===================

HOW TO PREVIEW
1. Extract the ZIP file.
2. Open index.html in a modern browser, or upload the entire folder to a static host.
3. Keep the assets folder beside index.html, style.css, and script.js.

WHAT'S INCLUDED
- Responsive dark futuristic portfolio design
- Icon-only desktop navigation and mobile bottom navigation
- Animated glowing borders, hover effects, reveal animations, and project filters
- About, skills, projects, photography/videography, editing, contact, and footer sections
- User-provided images and two supplied video files
- Edited black-suit portrait generated for the portfolio

PLEASE PERSONALIZE BEFORE PUBLISHING
- Replace hello@mrscott.dev in index.html and script.js with your real email.
- Add your actual GitHub, WhatsApp, Instagram, and live project URLs when ready.
- Confirm the Goliya image: the current Goliya card uses the supplied portfolio reference image as a placeholder because a clearly labeled Goliya screenshot was not identifiable among the provided images.
- Review the text describing the three bot projects and adjust it to match the real features.
- Skills listed are editable examples; remove any tools or technologies you do not use.

NOTES
This is a static front-end portfolio. Contact buttons, project URLs, and any real backend/API behavior need actual addresses or integrations before going live.
