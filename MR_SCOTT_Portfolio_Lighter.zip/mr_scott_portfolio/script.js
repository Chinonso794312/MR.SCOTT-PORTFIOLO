const navLinks=[...document.querySelectorAll('.nav-icon')];
const sections=[...document.querySelectorAll('main section[id]')];
const setActive=(id)=>navLinks.forEach(a=>a.classList.toggle('active',a.getAttribute('href')==='#'+id));
if('IntersectionObserver'in window){const sectionObserver=new IntersectionObserver(entries=>entries.forEach(entry=>{if(entry.isIntersecting)setActive(entry.target.id)}),{rootMargin:'-35% 0px -55% 0px'});sections.forEach(s=>sectionObserver.observe(s));const revealObserver=new IntersectionObserver(entries=>entries.forEach(e=>{if(e.isIntersecting){e.target.classList.add('visible');revealObserver.unobserve(e.target)}}),{threshold:.12});document.querySelectorAll('.section-heading,.about-grid,.skill-card,.project-feature,.project-card,.visual-card,.editing-callout,.contact-panel').forEach(el=>{el.classList.add('reveal');revealObserver.observe(el)})}
const menuToggle=document.getElementById('menuToggle');const mobileMenu=document.getElementById('mobileMenu');
if(menuToggle&&mobileMenu){menuToggle.addEventListener('click',()=>mobileMenu.classList.toggle('open'));mobileMenu.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>mobileMenu.classList.remove('open')))}
const tabs=[...document.querySelectorAll('.visual-tab')],cards=[...document.querySelectorAll('.visual-card')];
tabs.forEach(tab=>tab.addEventListener('click',()=>{tabs.forEach(t=>t.classList.toggle('active',t===tab));const f=tab.dataset.filter;cards.forEach(card=>{card.hidden=!(f==='all'||card.dataset.category===f)})}));
const toast=document.getElementById('toast');function showToast(message){toast.textContent=message;toast.classList.add('show');setTimeout(()=>toast.classList.remove('show'),2600)}
document.getElementById('copyEmail')?.addEventListener('click',async()=>{const email='hello@mrscott.dev';try{await navigator.clipboard.writeText(email);showToast('Email copied — update it to your preferred address before publishing.')}catch(e){showToast('Email placeholder: '+email)}});
document.getElementById('year').textContent=new Date().getFullYear();
